//
//  MemeTViewCell.swift
//  meme 0.1
//
//  Created by Albandry on 5/8/19.
//  Copyright © 2019 Albandry. All rights reserved.
//

import UIKit

class MemeTViewCell: UITableViewCell {

    @IBOutlet weak var imageviewt: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
