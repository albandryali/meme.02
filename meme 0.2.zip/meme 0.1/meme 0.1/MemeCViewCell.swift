//
//  MemeCViewCell.swift
//  meme 0.1
//
//  Created by Albandry on 5/6/19.
//  Copyright © 2019 Albandry. All rights reserved.
//

import UIKit

class MemeCViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageviewcc: UIImageView!
    
    
}
