//
//  Meme.swift
//  meme 0.1
//
//  Created by Albandry on 4/18/19.
//  Copyright © 2019 Albandry. All rights reserved.
//

import UIKit
struct Meme {
    let topText: String!
    let bottomText: String!
    let  originalImage: UIImage!
    let  memedImage: UIImage!
    
}
